<?php
/**
 * Our game class, which does two things for us:
 *  1. It helps map data in PHP to our game table in MySQL simply by existing
 *     as as datatype with properties that match the columns.
 *  2. It has some validation and helper methods to assist with saving data
 *     to MySQL.
 */
class Game {

  // properties
  public $id;
  public $title;
  public $year;
  public $beaten = false; // shows now to declare an initial value
  public $system;
  public $developer;

  /**
   * Constructors are always named __construct, starting with two underscores.
   * Here we've added six parameters to initialize the six properties on our
   * object.
   */
  public function __construct($gameId = null, $gameTitle = '', $releaseYear = '',
    $hasCompleted = false, $systemId = '', $devId = '') {
    $this->id = $gameId;
    $this->title = $gameTitle;
    $this->year = $releaseYear;
    $this->beaten = $hasCompleted;
    $this->system = $systemId;
    $this->developer = $devId;
  }

  /**
   * This function will tell us if we have everything we need to save a game
   * to the database or not.
   */
  public function hasAllValues() {
    return !empty($this->title) && !empty($this->year) && !empty($this->system) &&
      !empty($this->developer);
  }

  /**
   * This function is a simple test of whether or not the year is numeric on
   * this game object.
   */
  public function yearIsNumeric() {
    return is_numeric($this->year);
  }

  /**
   * This function will generate the SQL necessary to save the game to the
   * database. Depending on whether the game has an ID, it will return either
   * an update (yes) or an insert (no) statement.
   */
  public function getQuery() {
    // note the curly braces where we call a method inside the double quotes
    if ($this->haveGameId()) {
      return "update game
        set title = '$this->title',
        release_year = '$this->year',
        beaten = {$this->beatenAsInt()},
        system_id = $this->system,
        developer_id = $this->developer
        where game_id = $this->id";
    } else {
      return "insert game (system_id, developer_id, title, release_year, beaten)
        values($this->system, $this->developer, '$this->title', '$this->year',
        {$this->beatenAsInt()})";
    }
  }

  /**
   * A simple function to determine whether we have a game ID or not on this
   * game object.
   */
  private function haveGameId() {
    return isset($this->id) && is_numeric($this->id);
  }

  /**
   * In PHP, we are using true or false for completed, but when we save to the
   * database, we need 1 or 0. This function does that conversion for us.
   */
  private function beatenAsInt() {
    return $this->beaten ? 1 : 0;
  }
}
