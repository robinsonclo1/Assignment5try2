<?php include 'include/header.php' ?>
<form action="login-handler.php" method="post">
<fieldset>
  <legend>Login</legend>
  <div>
    <label>Username:
      <input name="username" type="text" />
    </label>
  </div>
  <div>
    <label>Password:
      <input name="password" type="password" />
    </label>
  </div>
  <div>
    <button type="submit">Log in</button>
    <a href="./">Cancel</a>
  </div>
</fieldset>
</form>
<?php include 'include/footer.php' ?>
