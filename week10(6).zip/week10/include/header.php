<?php
session_start();
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <!-- viewport meta tag helps get correct scaling on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>week 7 - game form</title>
    <style>
      body {
        margin: 0;
        font: 16px normal Arial, sans-serif;
      }
      main {
        margin: 2% auto;
        width: 75%;
      }
      table {
        border-collapse: collapse;
      }
      th, td {
        border: 1px solid #eee;
        padding: 10px;
      }
      label, button {
        display: block;
        margin: 1em 0;
      }
      footer {
        font-size: 0.8em;
        margin: 2em 0;
        text-align: center;
      }
    </style>
  </head>
  <body>
    <main>
